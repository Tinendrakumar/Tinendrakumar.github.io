<template>
  <div id="app" :class="{ 'overlay-active': activeOverlay }">
    <!-- Animated Background -->
    <div class="bg-elements">
      <div class="floating-element floating-element-1"></div>
      <div class="floating-element floating-element-2"></div>
      <div class="floating-element floating-element-3"></div>
      <div class="mesh-gradient"></div>
    </div>

    <!-- Navigation -->
    <Navbar @show-overlay="setActiveOverlay" />

    <!-- Router View for Main Pages (Home, Admin) -->
    <router-view v-slot="{ Component }">
      <transition name="fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>

    <!-- Overlay Components (About, Resume, Projects, Contact) -->
    <transition name="slide-fade">
      <component
        v-if="activeOverlay"
        :is="activeOverlay"
        @close="clearActiveOverlay"
        class="overlay"
      />
    </transition>

    <!-- Footer -->
    <Footer @admin-access="showAdminModal = true" />

    <!-- Admin Access Modal -->
    <BaseModal v-if="showAdminModal" @close="showAdminModal = false">
      <div class="admin-login">
        <h3>Admin Access</h3>
        <input 
          type="password" 
          v-model="adminPassword" 
          placeholder="Enter admin password"
          @keyup.enter="checkAdminPassword"
        >
        <BaseButton @click="checkAdminPassword">Login</BaseButton>
      </div>
    </BaseModal>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import Navbar from '@/components/layout/Navbar.vue'
import Footer from '@/components/layout/Footer.vue'
import BaseModal from '@/components/ui/BaseModal.vue'
import BaseButton from '@/components/ui/BaseButton.vue'
import About from '@/views/About.vue'
import Resume from '@/views/Resume.vue'
import Projects from '@/views/Projects.vue'
import Contact from '@/views/Contact.vue'
import { useAuth } from '@/composables/useAuth'
import { useVisitorTracking } from '@/composables/useVisitorTracking'

export default {
  name: 'App',
  components: {
    Navbar,
    Footer,
    BaseModal,
    BaseButton,
    About,
    Resume,
    Projects,
    Contact
  },
  setup() {
    const router = useRouter()
    const { authenticateAdmin } = useAuth()
    const { trackVisitor } = useVisitorTracking()

    const activeOverlay = ref(null)
    const showAdminModal = ref(false)
    const adminPassword = ref('')
    const savedScrollPosition = ref(0)

    onMounted(() => {
      // Track visitor
      trackVisitor()
    })

    const setActiveOverlay = (componentName) => {
      // Save current scroll position before opening overlay
      savedScrollPosition.value = window.pageYOffset || document.documentElement.scrollTop

      // Set the overlay
      activeOverlay.value = componentName

      // Prevent body scroll and preserve position
      document.body.style.position = 'fixed'
      document.body.style.top = `-${savedScrollPosition.value}px`
      document.body.style.width = '100%'
      document.body.classList.add('overlay-active')
    }

    const clearActiveOverlay = () => {
      // Clear the overlay
      activeOverlay.value = null

      // Restore body scroll and position
      document.body.classList.remove('overlay-active')
      document.body.style.position = ''
      document.body.style.top = ''
      document.body.style.width = ''

      // Restore scroll position
      window.scrollTo(0, savedScrollPosition.value)
    }

    const checkAdminPassword = async () => {
      const isValid = await authenticateAdmin(adminPassword.value)
      if (isValid) {
        showAdminModal.value = false
        router.push('/admin')
      } else {
        alert('Invalid password')
      }
      adminPassword.value = ''
    }

    return {
      activeOverlay,
      showAdminModal,
      adminPassword,
      setActiveOverlay,
      clearActiveOverlay,
      checkAdminPassword
    }
  }
}
</script>

<style>
/* Import global styles */
@import url('./assets/styles/variables.css');
@import url('./assets/styles/animations.css');

/* App-level styles */
#app {
  min-height: 100vh;
  position: relative;
  overflow-x: hidden;
}

/* Animated Background Elements */
.bg-elements {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: -1;
  overflow: hidden;
}

.floating-element {
  position: absolute;
  border-radius: 50%;
  opacity: 0.6;
  animation: float 20s ease-in-out infinite;
}

.floating-element-1 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
  top: -150px;
  left: -150px;
  animation-delay: 0s;
}

.floating-element-2 {
  width: 200px;
  height: 200px;
  background: linear-gradient(135deg, #F472B6 0%, #FB7185 100%);
  top: 60%;
  right: -100px;
  animation-delay: -5s;
}

.floating-element-3 {
  width: 150px;
  height: 150px;
  background: linear-gradient(135deg, #6EE7B7 0%, #34D399 100%);
  bottom: 20%;
  left: 10%;
  animation-delay: -10s;
}

.mesh-gradient {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: 
    radial-gradient(circle at 20% 80%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(244, 114, 182, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 40% 40%, rgba(110, 231, 183, 0.1) 0%, transparent 50%);
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px) rotate(0deg);
  }
  33% {
    transform: translateY(-30px) rotate(120deg);
  }
  66% {
    transform: translateY(20px) rotate(240deg);
  }
}

/* Overlay styles */
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(15px);
  -webkit-backdrop-filter: blur(15px);
  z-index: 1001;
  overflow-y: auto;
  padding: 120px 40px 40px;
}

/* Overlay transitions */
.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: opacity 0.4s ease, transform 0.4s ease;
}

.slide-fade-enter-from,
.slide-fade-leave-to {
  opacity: 0;
  transform: translateY(30px);
}

/* Page transitions */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Scroll preservation styles */
body.overlay-active {
  overflow: hidden;
}

/* Admin login styles */
.admin-login {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 2rem;
  text-align: center;
}

.admin-login h3 {
  margin: 0 0 1rem 0;
  color: #1E293B;
  font-size: 1.5rem;
}

.admin-login input {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1px solid #E2E8F0;
  border-radius: 0.5rem;
  font-size: 1rem;
  transition: all 0.2s ease;
}

.admin-login input:focus {
  outline: none;
  border-color: #3B82F6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .overlay {
    padding: 100px 20px 20px;
  }
}
</style>