import { ref } from 'vue'

export function useAuth() {
  const isAuthenticated = ref(false)
  const adminPassword = import.meta.env.VITE_ADMIN_PASSWORD || 'admin123'

  const authenticateAdmin = async (password) => {
    if (password === adminPassword) {
      isAuthenticated.value = true
      localStorage.setItem('admin_authenticated', 'true')
      localStorage.setItem('admin_session', Date.now().toString())
      return true
    }
    return false
  }

  const logout = () => {
    isAuthenticated.value = false
    localStorage.removeItem('admin_authenticated')
    localStorage.removeItem('admin_session')
  }

  const checkAuthStatus = () => {
    const authStatus = localStorage.getItem('admin_authenticated')
    const sessionTime = localStorage.getItem('admin_session')
    const currentTime = Date.now()
    const sessionExpiry = 24 * 60 * 60 * 1000 // 24 hours

    if (authStatus === 'true' && sessionTime) {
      const elapsed = currentTime - parseInt(sessionTime)
      if (elapsed < sessionExpiry) {
        isAuthenticated.value = true
        return true
      } else {
        logout()
      }
    }
    return false
  }

  return {
    isAuthenticated,
    authenticateAdmin,
    logout,
    checkAuthStatus
  }
}