import { ref, onMounted, onUnmounted } from 'vue'
import { useFirebase } from './useFirebase'

export function useVisitorTracking() {
  const { trackVisitor, trackEvent } = useFirebase()

  const sessionStartTime = ref(Date.now())
  const pageViews = ref([])
  const interactions = ref([])

  // Track page visit
  const trackPageView = (pageName) => {
    const pageView = {
      page: pageName,
      timestamp: Date.now(),
      url: window.location.href
    }

    pageViews.value.push(pageView)
    trackEvent('page_view', pageView)
  }

  // Track user interaction
  const trackInteraction = (type, element, data = {}) => {
    const interaction = {
      type,
      element,
      timestamp: Date.now(),
      data
    }

    interactions.value.push(interaction)
    trackEvent('user_interaction', interaction)
  }

  // Track visitor session
  const trackVisitorSession = () => {
    const sessionData = {
      sessionStart: sessionStartTime.value,
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      screenResolution: `${screen.width}x${screen.height}`,
      referrer: document.referrer || 'direct',
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
    }

    trackVisitor(sessionData)
  }

  onMounted(() => {
    trackVisitorSession()
  })

  return {
    trackPageView,
    trackInteraction,
    trackVisitorSession,
    pageViews,
    interactions
  }
}