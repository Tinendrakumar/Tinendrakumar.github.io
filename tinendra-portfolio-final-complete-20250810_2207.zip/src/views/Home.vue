<template>
  <main class="homepage">
    <section class="hero">
      <div class="hero-container">
        <div class="hero-image">
          <div class="profile-placeholder">
            <div class="profile-initials">TK</div>
          </div>
        </div>
        <div class="hero-content">
          <h1 class="hero-title">Hello</h1>
          <p class="hero-subtitle">Here's who I am & what I do</p>
          <div class="hero-buttons">
            <BaseButton 
              variant="primary" 
              @click="showOverlay('Resume')"
            >
              RESUME
            </BaseButton>
            <BaseButton 
              variant="primary" 
              @click="showOverlay('Projects')"
            >
              PROJECTS
            </BaseButton>
          </div>
          <div class="hero-description">
            <p>{{ personalInfo.intro }}</p>
            <p>{{ personalInfo.description }}</p>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
import { onMounted } from 'vue'
import BaseButton from '@/components/ui/BaseButton.vue'
import { useVisitorTracking } from '@/composables/useVisitorTracking'

export default {
  name: 'Home',
  components: {
    BaseButton
  },
  setup() {
    const { trackPageView } = useVisitorTracking()

    const personalInfo = {
      intro: "Passionate project manager with expertise in leading cross-functional teams and delivering innovative solutions. I specialize in agile methodologies and digital transformation initiatives.",
      description: "With extensive experience in project management, I help organizations streamline processes and achieve their strategic objectives through effective leadership and collaboration."
    }

    const showOverlay = (componentName) => {
      // Find the parent app component and call its method
      const app = document.getElementById('app').__vue_app__.config.globalProperties
      if (app && app.$parent) {
        app.$parent.setActiveOverlay(componentName)
      } else {
        // Alternative method using custom event
        window.dispatchEvent(new CustomEvent('show-overlay', { detail: componentName }))
      }
    }

    onMounted(() => {
      trackPageView('home')

      // Listen for overlay show events from buttons
      window.addEventListener('show-overlay', (event) => {
        const app = document.getElementById('app')
        if (app && app.__vue_app__) {
          // Get the root component instance
          const rootInstance = app.__vue_app__._instance
          if (rootInstance && rootInstance.setupState.setActiveOverlay) {
            rootInstance.setupState.setActiveOverlay(event.detail)
          }
        }
      })
    })

    return {
      personalInfo,
      showOverlay
    }
  }
}
</script>

<style scoped>
.homepage {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem 1rem;
  background: linear-gradient(135deg, #FEFCE8 0%, #FEF3C7 100%);
}

.hero {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
}

.hero-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
}

.hero-image {
  display: flex;
  justify-content: center;
}

.profile-placeholder {
  width: 300px;
  height: 300px;
  border-radius: 50%;
  background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 20px 60px rgba(59, 130, 246, 0.3);
  transition: transform 0.3s ease;
  animation: profileFloat 6s ease-in-out infinite;
}

.profile-placeholder:hover {
  transform: scale(1.05);
}

.profile-initials {
  font-size: 4rem;
  font-weight: bold;
  color: white;
}

.hero-content {
  max-width: 500px;
}

.hero-title {
  font-size: 4rem;
  font-weight: bold;
  color: #1E293B;
  margin-bottom: 0.5rem;
  line-height: 1.2;
  animation: titleSlideIn 0.8s ease-out;
}

.hero-subtitle {
  font-size: 1.25rem;
  color: #64748B;
  margin-bottom: 2rem;
  animation: subtitleSlideIn 0.8s ease-out 0.2s both;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  animation: buttonsSlideIn 0.8s ease-out 0.4s both;
}

.hero-description {
  color: #475569;
  line-height: 1.6;
  animation: descriptionFadeIn 0.8s ease-out 0.6s both;
}

.hero-description p {
  margin-bottom: 1rem;
}

.hero-description p:last-child {
  margin-bottom: 0;
}

/* Animations */
@keyframes profileFloat {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
}

@keyframes titleSlideIn {
  from {
    opacity: 0;
    transform: translateY(-30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes subtitleSlideIn {
  from {
    opacity: 0;
    transform: translateX(-30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes buttonsSlideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes descriptionFadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@media (max-width: 768px) {
  .hero-container {
    grid-template-columns: 1fr;
    gap: 2rem;
    text-align: center;
  }

  .hero-title {
    font-size: 3rem;
  }

  .profile-placeholder {
    width: 200px;
    height: 200px;
  }

  .profile-initials {
    font-size: 3rem;
  }

  .hero-buttons {
    justify-content: center;
  }
}
</style>