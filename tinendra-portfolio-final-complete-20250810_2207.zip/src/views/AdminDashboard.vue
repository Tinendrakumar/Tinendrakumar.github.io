<template>
  <div class="admin-dashboard">
    <div class="dashboard-header">
      <h1>Admin Dashboard</h1>
      <div class="header-actions">
        <BaseButton variant="outline" @click="logout">Logout</BaseButton>
      </div>
    </div>

    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2"/>
            <circle cx="9" cy="7" r="4" stroke="currentColor" stroke-width="2"/>
            <path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="currentColor" stroke-width="2"/>
            <path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <div class="stat-content">
          <h3>Total Visitors</h3>
          <p class="stat-number">{{ totalVisitors }}</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="currentColor" stroke-width="2"/>
            <polyline points="22,6 12,13 2,6" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <div class="stat-content">
          <h3>Contact Submissions</h3>
          <p class="stat-number">{{ totalContacts }}</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <polyline points="22,12 18,12 15,21 9,3 6,12 2,12" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <div class="stat-content">
          <h3>Page Views</h3>
          <p class="stat-number">{{ totalPageViews }}</p>
        </div>
      </div>
    </div>

    <div class="dashboard-content">
      <div class="dashboard-section">
        <h2>Recent Contact Submissions</h2>
        <div class="contacts-list" v-if="contacts.length > 0">
          <div v-for="contact in contacts.slice(0, 5)" :key="contact.id" class="contact-item">
            <div class="contact-header">
              <h4>{{ contact.firstName }} {{ contact.lastName }}</h4>
              <span class="contact-date">{{ formatDate(contact.timestamp) }}</span>
            </div>
            <p class="contact-email">{{ contact.email }}</p>
            <p class="contact-subject"><strong>Subject:</strong> {{ contact.subject }}</p>
            <p class="contact-message">{{ contact.message }}</p>
            <div class="contact-visitor-info" v-if="contact.visitor">
              <small>
                <strong>Visitor Info:</strong> 
                {{ contact.visitor.city }}, {{ contact.visitor.country }} | 
                {{ contact.visitor.ip }} | 
                {{ contact.visitor.platform }}
              </small>
            </div>
          </div>
        </div>
        <div v-else class="empty-state">
          <p>No contact submissions yet.</p>
        </div>
      </div>

      <div class="dashboard-section">
        <h2>Recent Visitors</h2>
        <div class="visitors-list" v-if="visitors.length > 0">
          <div v-for="visitor in visitors.slice(0, 10)" :key="visitor.id" class="visitor-item">
            <div class="visitor-info">
              <div class="visitor-location">
                <strong>{{ visitor.city || 'Unknown' }}, {{ visitor.country || 'Unknown' }}</strong>
              </div>
              <div class="visitor-details">
                <span>{{ visitor.ip }}</span> • 
                <span>{{ visitor.platform }}</span> • 
                <span>{{ formatDate(visitor.timestamp) }}</span>
              </div>
            </div>
          </div>
        </div>
        <div v-else class="empty-state">
          <p>No visitor data yet.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import BaseButton from '@/components/ui/BaseButton.vue'
import { useAuth } from '@/composables/useAuth'
import { useFirebase } from '@/composables/useFirebase'

export default {
  name: 'AdminDashboard',
  components: {
    BaseButton
  },
  setup() {
    const router = useRouter()
    const { logout: authLogout } = useAuth()
    const { getContactSubmissions, getVisitorAnalytics } = useFirebase()

    const contacts = ref([])
    const visitors = ref([])

    const totalVisitors = computed(() => visitors.value.length)
    const totalContacts = computed(() => contacts.value.length)
    const totalPageViews = computed(() => {
      return visitors.value.reduce((total, visitor) => total + (visitor.pageViews || 1), 0)
    })

    const loadData = async () => {
      try {
        const [contactsData, visitorsData] = await Promise.all([
          getContactSubmissions(),
          getVisitorAnalytics()
        ])

        contacts.value = contactsData
        visitors.value = visitorsData
      } catch (error) {
        console.error('Error loading dashboard data:', error)
      }
    }

    const formatDate = (timestamp) => {
      if (!timestamp) return 'Unknown'

      let date
      if (timestamp.toDate) {
        date = timestamp.toDate()
      } else if (typeof timestamp === 'number') {
        date = new Date(timestamp)
      } else {
        date = new Date(timestamp)
      }

      return date.toLocaleString()
    }

    const logout = () => {
      authLogout()
      router.push('/')
    }

    onMounted(() => {
      loadData()
    })

    return {
      contacts,
      visitors,
      totalVisitors,
      totalContacts,
      totalPageViews,
      formatDate,
      logout
    }
  }
}
</script>

<style scoped>
.admin-dashboard {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.dashboard-header h1 {
  color: white;
  font-size: 2rem;
  margin: 0;
}

.dashboard-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 3rem;
}

.stat-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 1rem;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  background: rgba(59, 130, 246, 0.1);
  border-radius: 0.75rem;
  color: #3B82F6;
}

.stat-content h3 {
  margin: 0 0 0.25rem 0;
  color: #64748B;
  font-size: 0.875rem;
  font-weight: 500;
}

.stat-number {
  margin: 0;
  color: #1E293B;
  font-size: 1.75rem;
  font-weight: bold;
}

.dashboard-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
}

.dashboard-section {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 1rem;
  padding: 1.5rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.dashboard-section h2 {
  color: #1E293B;
  margin: 0 0 1.5rem 0;
  font-size: 1.25rem;
}

.contact-item, .visitor-item {
  padding: 1rem;
  border: 1px solid #E2E8F0;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
}

.contact-item:last-child, .visitor-item:last-child {
  margin-bottom: 0;
}

.contact-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.contact-header h4 {
  margin: 0;
  color: #1E293B;
}

.contact-date {
  color: #64748B;
  font-size: 0.875rem;
}

.contact-email {
  color: #3B82F6;
  font-size: 0.875rem;
  margin: 0.25rem 0;
}

.contact-subject, .contact-message {
  color: #475569;
  margin: 0.5rem 0;
  font-size: 0.875rem;
}

.contact-message {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.contact-visitor-info {
  margin-top: 0.5rem;
  padding-top: 0.5rem;
  border-top: 1px solid #E2E8F0;
  color: #64748B;
}

.visitor-info {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.visitor-location {
  color: #1E293B;
}

.visitor-details {
  color: #64748B;
  font-size: 0.875rem;
}

.empty-state {
  text-align: center;
  color: #64748B;
  font-style: italic;
  padding: 2rem 0;
}

@media (max-width: 768px) {
  .admin-dashboard {
    padding: 1rem;
  }

  .dashboard-header {
    flex-direction: column;
    gap: 1rem;
    align-items: flex-start;
  }

  .dashboard-content {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
}
</style>